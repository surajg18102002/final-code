import azure.functions as func
import logging
import json
import os
import io
import re
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from azure.storage.blob import BlobServiceClient

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

_df_cache = None


def load_knowledge_base():
    global _df_cache
    if _df_cache is not None:
        logging.info("Using cached knowledge base.")
        return _df_cache

    logging.info("Loading knowledge base from blob storage...")

    conn_str  = os.environ["BLOB_CONNECTION_STRING"]
    container = os.environ["BLOB_CONTAINER_NAME"]
    filename  = os.environ["BLOB_FILE_NAME"]

    blob_service = BlobServiceClient.from_connection_string(conn_str)
    blob_client  = blob_service.get_blob_client(container=container, blob=filename)
    blob_data    = blob_client.download_blob().readall()

    # Try UTF-8 first, fall back to latin-1 which handles all single-byte encodings
    try:
        df = pd.read_csv(io.BytesIO(blob_data), encoding='utf-8')
    except UnicodeDecodeError:
        logging.warning("UTF-8 failed, trying latin-1 encoding")
        df = pd.read_csv(io.BytesIO(blob_data), encoding='latin-1')
    df.columns = df.columns.str.strip()

    df = df.rename(columns={
        'Number':             'number',
        'Configuration item': 'config_item',
        'Work notes':         'work_notes',
        'Resolution notes':   'resolution_notes'
    })

    df['work_notes']       = df['work_notes'].fillna('')
    df['resolution_notes'] = df['resolution_notes'].fillna('')
    df['config_item']      = df['config_item'].fillna('')

    df['search_text'] = df.apply(
        lambda r: build_search_text(r['work_notes'], r['resolution_notes'], r['config_item']),
        axis=1
    )

    df = df[df['search_text'].str.strip() != ''].reset_index(drop=True)

    _df_cache = df
    logging.info(f"Loaded {len(df)} records, {df['config_item'].nunique()} config items.")
    return df


def build_search_text(work_notes: str, resolution_notes: str, config_item: str) -> str:
    combined = work_notes + ' ' + resolution_notes
    combined = re.sub(r'\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2} [AP]M - .+?\(Work notes\)', ' ', combined)
    for phrase in [
        'Task auto-reassigned to Managed Services team',
        'Work notes from INCTASK',
        'Please investigate',
        'Job Output can be found in Tidal',
        'Please see work notes for parent group and agent information',
    ]:
        combined = combined.replace(phrase, ' ')
    combined = re.sub(r'\s+', ' ', combined).strip()
    return f"{config_item} {combined}"


def extract_resolution_action(work_notes: str, resolution_notes: str) -> str:
    combined = work_notes + '\n' + resolution_notes
    combined = re.sub(r'\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2} [AP]M - .+?\(Work notes\)', '\n', combined)
    for phrase in [
        'Task auto-reassigned to Managed Services team',
        'Work notes from INCTASK',
        'Please investigate',
        'Job Output can be found in Tidal',
        'Please see work notes for parent group and agent information',
    ]:
        combined = combined.replace(phrase, '')
    combined = re.sub(r'\n+', ' ', combined)
    combined = re.sub(r'\s+', ' ', combined).strip()
    return combined if combined else 'No resolution details available'


def find_similar_tickets(df, config_item: str, query_text: str, top_n: int = 3):
    filtered = df[df['config_item'].str.strip() == config_item.strip()].copy()
    logging.info(f"Stage 1 [{config_item}]: {len(filtered)} tickets")

    if len(filtered) < 15:
        logging.info("< 15 results — expanding to full dataset")
        filtered = df.copy()

    if len(filtered) == 0:
        return []

    corpus = filtered['search_text'].tolist()
    corpus_with_query = corpus + [query_text]

    try:
        vectorizer = TfidfVectorizer(
            stop_words='english',
            ngram_range=(1, 2),
            min_df=1,
            max_features=8000
        )
        tfidf_matrix = vectorizer.fit_transform(corpus_with_query)
    except Exception as e:
        logging.error(f"TF-IDF error: {e}")
        return []

    query_vector  = tfidf_matrix[-1]
    corpus_matrix = tfidf_matrix[:-1]
    similarities  = cosine_similarity(query_vector, corpus_matrix).flatten()

    filtered = filtered.copy()
    filtered['similarity'] = similarities
    top_results = filtered.sort_values('similarity', ascending=False).head(top_n)

    results = []
    for _, row in top_results.iterrows():
        results.append({
            "ticket_number":     row['number'],
            "config_item":       row['config_item'],
            "resolution_action": extract_resolution_action(row['work_notes'], row['resolution_notes'])[:800],
            "similarity_score":  round(float(row['similarity']), 4)
        })

    return results


@app.route(route="find-similar-tickets", methods=["POST", "GET"])
def find_similar_tickets_http(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("find-similar-tickets triggered.")

    # ── Accept params from EITHER query string OR JSON body ──
    # This avoids all JSON escaping issues in Logic App
    job_name      = req.params.get("job_name", "")
    job_id        = req.params.get("job_id", "")
    ticket_number = req.params.get("ticket_number", "")

    # If not in query string, try JSON body
    if not job_name:
        try:
            body      = req.get_json()
            job_name  = body.get("job_name", "").strip()
            job_id    = body.get("job_id", "").strip()
            ticket_number = body.get("ticket_number", "").strip()
        except Exception:
            pass

    job_name      = job_name.strip()
    job_id        = job_id.strip()
    ticket_number = ticket_number.strip()

    if not job_name:
        return func.HttpResponse(
            json.dumps({"error": "job_name is required"}),
            status_code=400,
            mimetype="application/json"
        )

    config_item = job_name
    query_text  = f"{job_name} {config_item} Completed Abnormally"

    try:
        df    = load_knowledge_base()
        top_3 = find_similar_tickets(df, config_item, query_text, top_n=3)
    except Exception as e:
        logging.error(f"Search error: {e}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500,
            mimetype="application/json"
        )

    response = {
        "ticket_number": ticket_number,
        "job_name":      job_name,
        "top_3_similar": top_3
    }

    logging.info(f"Returning {len(top_3)} results for {ticket_number} / {job_name}")

    return func.HttpResponse(
        json.dumps(response, indent=2),
        status_code=200,
        mimetype="application/json"
    )
